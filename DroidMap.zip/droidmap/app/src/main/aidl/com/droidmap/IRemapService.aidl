package com.droidmap;

interface IRemapService {
    void destroy() = 16777114; // Shizuku-reserved id

    // "path|name|kind" per line (kind = pad / kbd / other); lines starting with "!" are diagnostics
    String listDevices() = 1;
    // Opens the device and keeps reading it. Returns "ok..." or "error: ..."
    String start(String devicePath, String configJson, boolean inject) = 2;
    // Hot-swap mapping + calibration without restarting the reader
    void setConfig(String configJson) = 3;
    // Turn injecting into games on/off while the reader keeps running
    void setInject(boolean inject) = 4;
    void stop() = 5;
    // {"keySeq":n,"key":code,"err":"","inject":b,"grabbed":b,"abs":{"code":[raw,min,max,first]}}
    String snapshot() = 6;
    void resetRange() = 7;
}
