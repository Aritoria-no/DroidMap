package com.droidmap;

interface IRemapService {
    void destroy() = 16777114; // Shizuku-reserved id

    // "path|name" per line
    String listDevices() = 1;
    // inject=false: monitor only (calibration / learn). Returns "ok..." or "error: ..."
    String start(String devicePath, String configJson, boolean inject) = 2;
    void stop() = 3;
    // {"keySeq":n,"key":code,"err":"","abs":{"code":[raw,min,max]}}
    String snapshot() = 4;
    // restart min/max tracking from current values
    void resetRange() = 5;
}
