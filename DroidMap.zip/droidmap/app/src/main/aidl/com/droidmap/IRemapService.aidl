package com.droidmap;

interface IRemapService {
    void destroy() = 16777114; // Shizuku-reserved id

    // "path|name" per line
    String listDevices();
    // inject=false: monitor only (calibration / learn). Returns "ok..." or "error: ..."
    String start(String devicePath, String configJson, boolean inject);
    void stop();
    // {"keySeq":n,"key":code,"err":"","abs":{"code":[raw,min,max]}}
    String snapshot();
    // restart min/max tracking from current values
    void resetRange();
}
