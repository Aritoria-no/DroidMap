package com.droidmap

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    companion object { const val INFO = 0; const val OK = 1; const val ERR = 2 }

    private data class Dev(val path: String, val name: String, val kind: String)

    private var svc: IRemapService? = null
    private var binding = false
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences

    // persisted state
    private val cals = HashMap<Int, Cal>()
    private val binds = ArrayList<Binding>()
    private val roles = intArrayOf(-1, -1, -1, -1) // raw axis code for: left X, left Y, right X, right Y
    private var mappingOn = true
    private var selectedName = ""
    private var selectedPath = ""

    // live data
    private val snapAbs = HashMap<Int, IntArray>() // code -> [raw, min, max, first]
    private var keySeq = 0
    private var lastKey = -1
    private var lastErr = ""
    private var lastBtnText = "—"
    private var lastAxisText = "—"

    // views
    private lateinit var banner: TextView
    private lateinit var pages: List<View>
    private lateinit var shizukuInfo: TextView
    private lateinit var devSpinner: Spinner
    private lateinit var deviceDebug: TextView
    private lateinit var mapSwitch: Switch
    private val sticks = arrayOfNulls<StickView>(2)
    private val liveLines = arrayOfNulls<TextView>(4)
    private val dzBars = arrayOfNulls<SeekBar>(2)
    private val dzTexts = arrayOfNulls<TextView>(2)
    private val invBoxes = arrayOfNulls<CheckBox>(4)
    private lateinit var wizText: TextView
    private lateinit var wizLive: TextView
    private lateinit var wizStartBtn: Button
    private lateinit var wizNextBtn: Button
    private lateinit var wizSkipBtn: Button
    private lateinit var wizCancelBtn: Button
    private lateinit var lastInput: TextView
    private lateinit var mapBox: LinearLayout

    private var devices = listOf<Dev>()
    private var startedPath = ""
    private val logBuf = StringBuilder()
    private var logView: TextView? = null
    private var attempt = 0
    private val timeFmt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
    private var uiUpdating = false

    // calibration wizard
    private var wiz = -1
    private val wizNew = intArrayOf(-1, -1, -1, -1)
    private val wizCal = arrayOfNulls<Cal>(4)
    private val wizSteps = arrayOf(
        "LEFT stick: move it LEFT ↔ RIGHT",
        "LEFT stick: move it UP ↕ DOWN",
        "RIGHT stick: move it LEFT ↔ RIGHT",
        "RIGHT stick: move it UP ↕ DOWN"
    )
    private val axisLabels = arrayOf("Left X", "Left Y", "Right X", "Right Y")

    // button learning
    private var learnTarget: Target? = null
    private var learnKeySeq = 0
    private var learnStart = 0L
    private var learnAbs = -1
    private var learnAbsAt = 0L

    // ---------------- Shizuku ----------------

    private val conn: ServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder?) {
            binding = false
            ui.removeCallbacks(connectTimeout)
            if (b == null || !b.pingBinder()) { msg("Shizuku service returned an invalid binder.", ERR); return }
            log("service connected")
            svc = IRemapService.Stub.asInterface(b)
            shizukuInfo.text = "Shizuku: running · permission granted · service connected ✔"
            msg("Connected to Shizuku.", OK)
            refreshDevices()
        }
        override fun onServiceDisconnected(n: ComponentName) {
            log("service disconnected")
            svc = null; binding = false; startedPath = ""
            shizukuInfo.text = "Shizuku: service disconnected"
            msg("Lost connection to the Shizuku service. Tap Connect on the Setup tab.", ERR)
        }
    }
    private val connectTimeout: Runnable = Runnable {
        if (svc == null) {
            if (attempt == 1) {
                attempt = 2
                log("no service after 15s in foreground mode; retrying in background (daemon) mode")
                readSvcLog()
                try { Shizuku.unbindUserService(userArgs(false), conn, true) } catch (e: Throwable) { log("unbind: $e") }
                startBind(true)
            } else {
                binding = false
                log("no service after the second try")
                readSvcLog()
                msg("The Shizuku service didn't start after two tries. Go to Setup → Diagnostics, tap Copy log and send it to me.", ERR)
            }
        }
    }
    private val permListener: Shizuku.OnRequestPermissionResultListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        log("permission result: $result")
        if (result == PackageManager.PERMISSION_GRANTED) connect() else msg("Shizuku permission was denied.", ERR)
    }
    private val deadListener: Shizuku.OnBinderDeadListener = Shizuku.OnBinderDeadListener {
        ui.post {
            log("Shizuku binder died (Shizuku stopped)")
            ui.removeCallbacks(connectTimeout)
            svc = null; binding = false; startedPath = ""
            shizukuInfo.text = "Shizuku: stopped"
            msg("Shizuku stopped. Open the Shizuku app, start it again (stay on Wi-Fi), then come back.", ERR)
        }
    }
    private val binderListener: Shizuku.OnBinderReceivedListener = Shizuku.OnBinderReceivedListener { log("Shizuku binder received"); connect() }

    private fun userArgs(daemon: Boolean): Shizuku.UserServiceArgs {
        val ver = packageManager.getPackageInfo(packageName, 0).longVersionCode.toInt()
        return Shizuku.UserServiceArgs(ComponentName(packageName, RemapService::class.java.name))
            .processNameSuffix(if (daemon) "remap_d$ver" else "remap_f$ver").daemon(daemon).version(ver)
    }

    private fun connect() {
        if (svc != null) { refreshDevices(); return }
        if (binding) { msg("Still starting the Shizuku service… give it a few seconds.", INFO); return }
        val shizukuApp = try { packageManager.getPackageInfo("moe.shizuku.privileged.api", 0).versionName } catch (e: Throwable) { null }
        log("Shizuku app installed: ${shizukuApp ?: "NO"}; Android API ${android.os.Build.VERSION.SDK_INT}")
        val ping = try { Shizuku.pingBinder() } catch (e: Throwable) { log("pingBinder threw: $e"); false }
        log("connect(): pingBinder=$ping")
        if (!ping) {
            shizukuInfo.text = "Shizuku: not reachable"
            msg(if (shizukuApp == null) "The Shizuku app isn't installed." else "DroidMap can't reach Shizuku. Tap Open Shizuku app, start it with Wireless debugging (stay on Wi-Fi), then return here.", ERR); return
        }
        val granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        val ver = try { Shizuku.getVersion() } catch (e: Throwable) { -1 }
        val uid = try { Shizuku.getUid() } catch (e: Throwable) { -1 }
        log("permission granted=$granted, Shizuku API v$ver, server uid=$uid")
        if (!granted) {
            shizukuInfo.text = "Shizuku: running · permission needed"
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                msg("Permission was denied permanently. In the Shizuku app, allow DroidMap.", ERR)
            } else {
                msg("Allow DroidMap in the Shizuku permission dialog.", INFO)
                Shizuku.requestPermission(100)
            }
            return
        }
        attempt = 1
        try { svcLogFile().delete() } catch (_: Throwable) {}
        startBind(false)
    }

    private fun startBind(daemon: Boolean) {
        binding = true
        shizukuInfo.text = "Shizuku: running · permission granted · starting service (${if (daemon) "background" else "foreground"} mode)…"
        try {
            Shizuku.bindUserService(userArgs(daemon), conn)
            log("bindUserService(daemon=$daemon) called")
        } catch (e: Throwable) {
            binding = false
            log("bindUserService failed: $e")
            msg("Couldn't start the Shizuku service: $e", ERR)
            return
        }
        ui.removeCallbacks(connectTimeout)
        ui.postDelayed(connectTimeout, 15000)
    }

    private fun resetAndReconnect() {
        log("reset requested")
        ui.removeCallbacks(connectTimeout)
        for (d in booleanArrayOf(true, false)) {
            try { Shizuku.unbindUserService(userArgs(d), conn, true) } catch (e: Throwable) { log("unbind($d): $e") }
        }
        svc = null; binding = false; startedPath = ""
        msg("Reconnecting…", INFO)
        ui.postDelayed({ connect() }, 600)
    }

    private fun svcLogFile(): java.io.File = java.io.File(getExternalFilesDir(null), "service.log")

    private fun readSvcLog() {
        try {
            val f = svcLogFile()
            log("service log: " + if (f.exists()) f.readText().takeLast(1500) else "(none: the service process never wrote anything)")
        } catch (e: Throwable) { log("service log read failed: $e") }
    }

    private fun log(s: String) {
        logBuf.append(timeFmt.format(java.util.Date())).append(' ').append(s).append('\n')
        if (logBuf.length > 8000) logBuf.delete(0, logBuf.length - 6000)
        logView?.text = logBuf
    }

    // ---------------- helpers ----------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun msg(text: String, kind: Int = INFO) {
        banner.text = text
        log(text)
        banner.setBackgroundColor(when (kind) { OK -> 0xFF2E7D32.toInt(); ERR -> 0xFFC62828.toInt(); else -> 0xFF37474F.toInt() })
        if (kind != INFO) Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    private fun btn(label: String, f: () -> Unit) = Button(this).apply { text = label; setOnClickListener { f() } }
    private fun head(s: String) = TextView(this).apply {
        text = s; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(20), 0, dp(6))
    }
    private fun note(s: String) = TextView(this).apply { text = s; textSize = 13f; alpha = 0.7f }
    private fun col() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(24))
    }
    private fun scroll(inner: View) = ScrollView(this).apply { addView(inner) }

    private fun allBinds(): List<Binding> = binds + (0..3).mapNotNull { i ->
        if (roles[i] >= 0) Targets.find(1, i, 1f)?.let { Binding(3, roles[i], it, 1) } else null
    }

    private fun pushConfig() {
        try { svc?.setConfig(Codec.config(allBinds(), cals)) } catch (_: Exception) {}
    }
    private fun saveCals() = prefs.edit().putString("cals", Codec.calsToJson(cals).toString())
        .putString("roles", roles.joinToString(",")).apply()
    private fun saveBinds() = prefs.edit().putString("binds", Codec.bindsToJson(binds).toString()).apply()

    private fun srcName(b: Binding) =
        if (b.srcType == 1) Names.key(b.srcCode) else "${Names.abs(b.srcCode)} ${if (b.srcSign > 0) "+" else "−"}"

    // ---------------- lifecycle ----------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("droidmap", Context.MODE_PRIVATE)
        val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { prefs.edit().putString("crash", android.util.Log.getStackTraceString(e)).commit() } catch (_: Throwable) {}
            prevHandler?.uncaughtException(t, e)
        }
        val crash = prefs.getString("crash", null)
        if (crash != null) { log("PREVIOUS CRASH:\n" + crash.take(1500)); prefs.edit().remove("crash").apply() }
        try {
            prefs.getString("cals", null)?.let { cals.putAll(Codec.calsFromJson(JSONObject(it))) }
            prefs.getString("binds", null)?.let { binds.addAll(Codec.bindsFromJson(JSONArray(it))) }
            prefs.getString("roles", null)?.split(",")?.forEachIndexed { i, s -> if (i < 4) roles[i] = s.toIntOrNull() ?: -1 }
        } catch (_: Exception) {}
        mappingOn = prefs.getBoolean("mappingOn", true)
        selectedName = prefs.getString("device", "") ?: ""
        selectedPath = prefs.getString("devicePath", "") ?: ""

        banner = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(0xFF37474F.toInt()); text = "Starting…"
        }
        pages = listOf(scroll(buildSetupPage()), scroll(buildSticksPage()), scroll(buildButtonsPage()))
        val content = FrameLayout(this)
        pages.forEach { content.addView(it) }
        val tabs = LinearLayout(this)
        listOf("Setup", "Sticks", "Buttons").forEachIndexed { i, n ->
            tabs.addView(btn(n) { showPage(i) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; fitsSystemWindows = true
            addView(banner)
            addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(tabs)
        }
        setContentView(root)
        showPage(0)
        refreshStickControls(); updateWizButtons(); buildMapRows()

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        ui.post(poll)
        if (crash != null) msg("DroidMap crashed last time. Setup → Diagnostics has the details.", ERR)
        connect()
    }

    override fun onResume() {
        super.onResume()
        // Coming back from the Shizuku app after starting it: connect quietly.
        try {
            if (svc == null && !binding && Shizuku.pingBinder() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) connect()
        } catch (e: Throwable) { log("onResume check: $e") }
    }

    private fun openShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i == null) msg("The Shizuku app isn't installed.", ERR) else startActivity(i)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    private fun showPage(i: Int) = pages.forEachIndexed { j, p -> p.visibility = if (i == j) View.VISIBLE else View.GONE }

    /** The controller must never drive DroidMap's own UI. */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val s = e.source
        val pad = (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
            (s and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD
        val chosen = selectedName.isNotEmpty() && e.device?.name == selectedName
        if (pad || chosen) return true
        return super.dispatchKeyEvent(e)
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        val s = e.source
        if ((s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
            (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD) return true
        return super.dispatchGenericMotionEvent(e)
    }

    // ---------------- Setup page ----------------

    private fun buildSetupPage(): LinearLayout {
        val c = col()
        c.addView(head("Shizuku"))
        shizukuInfo = TextView(this).apply { text = "Shizuku: checking…" }
        c.addView(shizukuInfo)
        c.addView(btn("Connect to Shizuku") { connect() })
        c.addView(btn("Open Shizuku app") { openShizuku() })
        c.addView(btn("Read service log") { readSvcLog() })

        c.addView(head("Controller"))
        c.addView(note("Pick the keyboard / controller you want to use. It's listened to in the background."))
        devSpinner = Spinner(this)
        devSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = onDevicePicked(pos)
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        c.addView(devSpinner)
        c.addView(btn("Refresh device list") { if (svc == null) connect() else refreshDevices() })
        c.addView(btn("Detect controller (press its buttons)") { detectController() })
        deviceDebug = note("")
        c.addView(deviceDebug)

        c.addView(head("Mapping"))
        mapSwitch = Switch(this).apply { text = "Mapping enabled"; isChecked = mappingOn }
        mapSwitch.setOnCheckedChangeListener { _, on ->
            mappingOn = on
            prefs.edit().putBoolean("mappingOn", on).apply()
            try { svc?.setInject(on) } catch (_: Exception) {}
            msg(if (on) "Mapping is ON: your controller now acts as a gamepad in games." else "Mapping is OFF.", INFO)
        }
        c.addView(mapSwitch)
        c.addView(note("Mapping is active as soon as a controller is selected. It keeps running in the background; you don't need to keep this app open."))

        c.addView(head("Diagnostics"))
        c.addView(btn("Reset & reconnect") { resetAndReconnect() })
        c.addView(btn("Copy log") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("DroidMap log", logBuf.toString()))
            Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show()
        })
        logView = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 11f; setTextIsSelectable(true); text = logBuf }
        c.addView(logView)
        return c
    }

    private fun refreshDevices() {
        val s = svc ?: return
        val raw = try { s.listDevices() } catch (e: Exception) { msg("Couldn't list devices: $e", ERR); return }
        val real = ArrayList<Dev>()
        val diag = ArrayList<String>()
        raw.lines().forEach { l ->
            if (l.startsWith("!")) diag.add(l.substring(1))
            else if (l.contains('|')) {
                val p = l.split('|')
                real.add(Dev(p[0], p.getOrElse(1) { "?" }, p.getOrElse(2) { "other" }))
            }
        }
        val order = mapOf("pad" to 0, "kbd" to 1, "other" to 2)
        real.sortBy { order[it.kind] ?: 3 }
        devices = listOf(Dev("", "", "")) + real
        val labels = devices.map {
            if (it.path.isEmpty()) "— choose your controller —"
            else "${when (it.kind) { "pad" -> "[Gamepad]"; "kbd" -> "[Keyboard]"; else -> "[Other]" }} ${it.name} (${it.path.substringAfterLast('/')})"
        }
        devSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        log("devices: ${real.size} found; notes=$diag")
        deviceDebug.text = "Found ${real.size} input devices." + if (diag.isNotEmpty()) "\n" + diag.joinToString("\n") else ""
        if (real.isEmpty()) { msg("No input devices found. See the note on the Setup tab.", ERR); return }
        var idx = devices.indexOfFirst { it.path.isNotEmpty() && it.name == selectedName && it.path == selectedPath }
        if (idx < 0) idx = devices.indexOfFirst { it.path.isNotEmpty() && it.name == selectedName }
        if (idx > 0) { startedPath = ""; devSpinner.setSelection(idx) }
        else msg("Connected. Choose your controller on the Setup tab.", INFO)
    }

    /** Controller names are often hidden ("Input device"), so find it by listening for presses instead of picking from the dropdown. */
    private fun detectController() {
        val s = svc
        if (s == null) { msg("Connect to Shizuku first.", ERR); return }
        msg("Press buttons and move the sticks on your controller for the next 6 seconds…", INFO)
        Thread {
            val r = try { s.detect(6000) } catch (e: Exception) { "!error: $e" }
            ui.post { onDetected(r) }
        }.start()
    }

    private fun onDetected(raw: String) {
        log("detect: " + raw.replace('\n', ' '))
        class Hit(val path: String, val pad: Int, val key: Int, val abs: Int)
        val hits = raw.lines().filter { it.contains('|') }.mapNotNull {
            val p = it.split('|')
            if (p.size < 4) null else Hit(p[0], p[1].toIntOrNull() ?: 0, p[2].toIntOrNull() ?: 0, p[3].toIntOrNull() ?: 0)
        }
        val best = hits.maxWithOrNull(compareBy<Hit>({ it.pad }, { it.key }, { it.abs }))
        if (best == null) { msg("No controller input detected. Check it's connected and keep pressing buttons during the 6 seconds.", ERR); return }
        val idx = devices.indexOfFirst { it.path == best.path }
        if (idx <= 0) { msg("Detected ${best.path}, but it isn't in the device list. Tap Refresh device list and try again.", ERR); return }
        startedPath = ""
        devSpinner.setSelection(idx)
        onDevicePicked(idx)
        msg("Controller found: ${best.path.substringAfterLast('/')} (${best.pad} button presses, ${best.abs} axis moves).", OK)
    }

    private fun onDevicePicked(pos: Int) {
        val d = devices.getOrNull(pos) ?: return
        if (d.path.isEmpty() || d.path == startedPath) return
        selectedName = d.name
        selectedPath = d.path
        prefs.edit().putString("device", d.name).putString("devicePath", d.path).apply()
        startReader()
    }

    private fun startReader() {
        val s = svc ?: return
        val d = devices.getOrNull(devSpinner.selectedItemPosition) ?: return
        if (d.path.isEmpty()) return
        val r = try { s.start(d.path, Codec.config(allBinds(), cals), mappingOn) } catch (e: Exception) { "error: $e" }
        if (r.startsWith("ok")) {
            startedPath = d.path
            msg("Listening to ${d.name}  ${r.removePrefix("ok")}", OK)
        } else {
            startedPath = ""
            msg(r, ERR)
        }
    }

    // ---------------- polling ----------------

    private val poll: Runnable = object : Runnable {
        override fun run() {
            val s = svc
            if (s != null && startedPath.isNotEmpty()) {
                try { onSnapshot(JSONObject(s.snapshot())) } catch (_: Exception) {}
            }
            ui.postDelayed(this, 50)
        }
    }

    private fun onSnapshot(o: JSONObject) {
        val abs = o.getJSONObject("abs")
        val prev = HashMap(snapAbs)
        snapAbs.clear()
        abs.keys().forEach { k ->
            val a = abs.getJSONArray(k)
            snapAbs[k.toInt()] = intArrayOf(a.getInt(0), a.getInt(1), a.getInt(2), a.getInt(3))
        }
        val ks = o.getInt("keySeq")
        if (ks != keySeq) {
            keySeq = ks; lastKey = o.getInt("key")
            if (ks > 0) lastBtnText = Names.key(lastKey)
        }
        for ((c, a) in snapAbs) {
            val p = prev[c] ?: continue
            val th = if (c == 16 || c == 17) 1 else 4
            if (Math.abs(a[0] - p[0]) >= th) lastAxisText = "${Names.abs(c)} = ${a[0]}"
        }
        lastInput.text = "Last button pressed:  $lastBtnText\nLast axis moved:  $lastAxisText"
        val e = o.optString("err")
        if (e.isNotEmpty() && e != lastErr) { lastErr = e; msg(e, ERR) }
        updateTester()
        if (wiz >= 0) updateWizLive()
        if (learnTarget != null) checkLearn()
    }

    // ---------------- Sticks page: tester + calibration ----------------

    private fun buildSticksPage(): LinearLayout {
        val c = col()
        c.addView(head("Stick tester"))
        c.addView(note("Move your sticks: the dot should follow. If an axis goes the wrong way, tick Invert."))
        val row = LinearLayout(this)
        for (i in 0..1) {
            val sv = StickView(this).apply { title = if (i == 0) "LEFT" else "RIGHT" }
            sticks[i] = sv
            row.addView(sv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        c.addView(row)
        for (i in 0..3) {
            liveLines[i] = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 12f }
            c.addView(liveLines[i])
        }
        for (s in 0..1) {
            dzTexts[s] = TextView(this).apply { setPadding(0, dp(10), 0, 0) }
            c.addView(dzTexts[s])
            dzBars[s] = SeekBar(this).apply {
                max = 40
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, p: Int, user: Boolean) {
                        if (uiUpdating) return
                        for (i in intArrayOf(2 * s, 2 * s + 1)) cals[roles[i]]?.dead = p / 100f
                        dzTexts[s]?.text = "${if (s == 0) "Left" else "Right"} stick deadzone: $p%"
                        saveCals()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) { pushConfig() }
                })
            }
            c.addView(dzBars[s])
            val r = LinearLayout(this)
            for (k in 0..1) {
                val i = 2 * s + k
                invBoxes[i] = CheckBox(this).apply {
                    text = "Invert ${axisLabels[i]}"
                    setOnCheckedChangeListener { _, v ->
                        if (uiUpdating) return@setOnCheckedChangeListener
                        val cal = cals[roles[i]]
                        if (cal == null) { msg("Calibrate the sticks first.", ERR) } else { cal.invert = v; saveCals(); pushConfig() }
                    }
                }
                r.addView(invBoxes[i], LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            c.addView(r)
        }

        c.addView(head("Calibrate sticks"))
        wizText = TextView(this).apply { text = "Tap Start and follow the steps. It finds which axes your sticks use and their range." }
        wizLive = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 12f; setPadding(0, dp(6), 0, dp(6)) }
        c.addView(wizText); c.addView(wizLive)
        wizStartBtn = btn("Start calibration") { wizStart() }
        wizNextBtn = btn("Next ▶") { wizNext() }
        wizSkipBtn = btn("Skip right stick") { wizSkip() }
        wizCancelBtn = btn("Cancel") { wizCancel() }
        listOf(wizStartBtn, wizNextBtn, wizSkipBtn, wizCancelBtn).forEach { c.addView(it) }
        return c
    }

    private fun refreshStickControls() {
        uiUpdating = true
        for (s in 0..1) {
            val d = ((cals[roles[2 * s]]?.dead ?: 0.10f) * 100).toInt()
            dzBars[s]?.progress = d
            dzTexts[s]?.text = "${if (s == 0) "Left" else "Right"} stick deadzone: $d%"
        }
        for (i in 0..3) invBoxes[i]?.isChecked = cals[roles[i]]?.invert ?: false
        uiUpdating = false
    }

    private fun axisValue(c: Int): Float {
        if (c < 0) return 0f
        val cal = cals[c] ?: return 0f
        val a = snapAbs[c] ?: return 0f
        return cal.norm(a[0])
    }

    private fun updateTester() {
        for (s in 0..1) {
            val cx = roles[2 * s]
            sticks[s]?.set(axisValue(cx), axisValue(roles[2 * s + 1]), cals[cx]?.dead ?: 0f)
        }
        for (i in 0..3) {
            val c = roles[i]
            liveLines[i]?.text = if (c < 0) "${axisLabels[i]}: not set" else
                "${axisLabels[i]}: axis $c  raw ${snapAbs[c]?.get(0) ?: "-"}  →  ${"%+.2f".format(axisValue(c))}"
        }
    }

    private fun updateWizButtons() {
        val on = wiz >= 0
        wizStartBtn.visibility = if (on) View.GONE else View.VISIBLE
        wizNextBtn.visibility = if (on) View.VISIBLE else View.GONE
        wizCancelBtn.visibility = if (on) View.VISIBLE else View.GONE
        wizSkipBtn.visibility = if (wiz >= 2) View.VISIBLE else View.GONE
        if (!on) wizLive.text = ""
    }

    private fun wizCandidate(): Int? {
        var best = -1; var bestRange = 0
        for ((c, a) in snapAbs) {
            if (wizNew.contains(c)) continue
            val r = a[2] - a[1]
            if (r > bestRange) { best = c; bestRange = r }
        }
        return if (best >= 0 && bestRange >= 8) best else null
    }

    private fun updateWizLive() {
        val c = wizCandidate()
        wizLive.text = if (c == null) "Nothing detected yet — move the stick."
        else "Detected ${Names.abs(c)}  range ${snapAbs[c]!![1]}..${snapAbs[c]!![2]}"
    }

    private fun wizStart() {
        if (svc == null || startedPath.isEmpty()) { msg("Connect to Shizuku and choose your controller on the Setup tab first.", ERR); return }
        wiz = 0; wizNew.fill(-1); wizCal.fill(null)
        wizBegin(); updateWizButtons()
    }

    private fun wizBegin() {
        try { svc?.resetRange() } catch (_: Exception) {}
        wizText.text = "Step ${wiz + 1} of 4\n${wizSteps[wiz]}\nMove it back and forth a few times, then LET GO and tap Next."
        wizSkipBtn.visibility = if (wiz >= 2) View.VISIBLE else View.GONE
    }

    private fun wizNext() {
        val c = wizCandidate()
        if (c == null) { msg("Nothing moved. Check that the right controller is selected, then move the stick.", ERR); return }
        val a = snapAbs[c]!!
        val range = a[2] - a[1]
        val mid = (a[1] + a[2]) / 2
        if (Math.abs(a[0] - mid) > range * 0.2) {
            msg("Let go of the stick first — it's still pushed to one side. Release it, then tap Next.", ERR); return
        }
        val old = cals[c]
        wizCal[wiz] = Cal(a[1], a[2], a[0], old?.dead ?: 0.10f, old?.invert ?: false)
        wizNew[wiz] = c
        msg("✔ ${axisLabels[wiz]} = ${Names.abs(c)} (range ${a[1]}..${a[2]}, centre ${a[0]})", OK)
        wiz++
        if (wiz >= 4) wizFinish() else { wizBegin(); updateWizButtons() }
    }

    private fun wizSkip() { wiz = 4; wizFinish() }

    private fun wizCancel() {
        wiz = -1; updateWizButtons()
        wizText.text = "Calibration cancelled. Nothing was changed."
        msg("Calibration cancelled.", INFO)
    }

    private fun wizFinish() {
        wiz = -1
        updateWizButtons()
        if (wizNew[0] < 0 || wizNew[1] < 0) {
            wizText.text = "✖ Calibration failed: the left stick wasn't detected. Nothing was changed."
            msg("Calibration failed: left stick not detected.", ERR); return
        }
        for (i in 0..3) {
            roles[i] = wizNew[i]
            wizCal[i]?.let { cals[wizNew[i]] = it }
        }
        saveCals(); pushConfig(); refreshStickControls()
        val sb = StringBuilder()
        for (i in 0..3) sb.append("${axisLabels[i]}: ").append(if (roles[i] >= 0) Names.abs(roles[i]) else "not set").append('\n')
        wizText.text = "✔ Calibration saved.\n$sb"
        msg("✔ Calibration saved. Flick the sticks to test them.", OK)
        AlertDialog.Builder(this).setTitle("✔ Calibration saved")
            .setMessage("$sb\nNow move the sticks — the dots above should follow. Use Invert if an axis is reversed.")
            .setPositiveButton("OK", null).show()
    }

    // ---------------- Buttons page ----------------

    private fun buildButtonsPage(): LinearLayout {
        val c = col()
        c.addView(head("Button mapper"))
        c.addView(note("Tap Set next to a gamepad button, then press a key/button (or move an axis) on your controller. Sticks are set up on the Sticks tab."))
        lastInput = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 13f; setPadding(0, dp(10), 0, dp(10)); text = "Last button pressed:  —\nLast axis moved:  —" }
        c.addView(lastInput)
        mapBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(mapBox)
        return c
    }

    private fun buildMapRows() {
        mapBox.removeAllViews()
        for (t in Targets.all) {
            val b = binds.firstOrNull { it.target == t }
            val row = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            left.addView(TextView(this).apply { text = t.label; typeface = Typeface.DEFAULT_BOLD })
            left.addView(TextView(this).apply {
                textSize = 13f
                text = when {
                    learnTarget == t -> "⏳ Waiting for your input…"
                    b != null -> "← ${srcName(b)}"
                    else -> "not set"
                }
                alpha = if (b == null && learnTarget != t) 0.5f else 1f
            })
            row.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(btn(if (learnTarget == t) "Cancel" else "Set") {
                if (learnTarget == t) { learnTarget = null; msg("Cancelled.", INFO); buildMapRows() } else startLearn(t)
            })
            if (b != null) row.addView(btn("✕") { binds.removeAll { it.target == t }; saveBinds(); pushConfig(); buildMapRows() })
            mapBox.addView(row)
        }
    }

    private fun startLearn(t: Target) {
        if (svc == null || startedPath.isEmpty()) { msg("Connect to Shizuku and choose your controller on the Setup tab first.", ERR); return }
        try { svc?.resetRange() } catch (_: Exception) {}
        learnTarget = t; learnKeySeq = keySeq; learnStart = SystemClock.uptimeMillis(); learnAbs = -1
        msg("Press the button on your controller for “${t.label}” (for triggers / hat, press fully)…", INFO)
        buildMapRows()
    }

    private fun checkLearn() {
        val t = learnTarget ?: return
        val now = SystemClock.uptimeMillis()
        if (keySeq > learnKeySeq) { bind(1, lastKey, 1); return }
        if (learnAbs >= 0) { if (now - learnAbsAt >= 400) finishAbsLearn(); return }
        if (now - learnStart > 10000) {
            learnTarget = null
            msg("No input detected for “${t.label}”. Make sure the right device is selected on Setup, then try again.", ERR)
            buildMapRows(); return
        }
        for ((c, a) in snapAbs) {
            val hat = c == 16 || c == 17
            val cal = cals[c]
            val need = if (hat) 1 else if (cal != null) ((cal.max - cal.min) * 0.4f).toInt().coerceAtLeast(4) else 60
            if (a[2] - a[1] >= need) {
                learnAbs = c; learnAbsAt = now
                msg("Detected ${Names.abs(c)} — hold it fully for a moment…", INFO)
                return
            }
        }
    }

    private fun finishAbsLearn() {
        val c = learnAbs
        val a = snapAbs[c] ?: run { learnAbs = -1; return }
        if (cals[c] == null) {
            cals[c] = if (c == 16 || c == 17) Cal(-1, 1, 0, 0f) else Cal(a[1], a[2], a[3], 0.05f)
            saveCals()
        }
        val rest = cals[c]!!.center
        bind(3, c, if (a[2] - rest >= rest - a[1]) 1 else -1)
    }

    private fun bind(type: Int, code: Int, sign: Int) {
        val t = learnTarget ?: return
        learnTarget = null; learnAbs = -1
        binds.removeAll { it.target == t }
        val b = Binding(type, code, t, sign)
        binds.add(b)
        saveBinds(); pushConfig(); buildMapRows()
        msg("✔ ${srcName(b)}  →  ${t.label}", OK)
    }
}
