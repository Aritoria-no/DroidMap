package com.droidmap

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONObject
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private var svc: IRemapService? = null
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences

    private lateinit var status: TextView
    private lateinit var live: TextView
    private lateinit var calBox: LinearLayout
    private lateinit var bindBox: LinearLayout
    private lateinit var devSpinner: Spinner
    private lateinit var targetSpinner: Spinner

    private var devices = listOf<Pair<String, String>>()
    private val cals = HashMap<Int, Cal>()
    private val binds = ArrayList<Binding>()

    private var monitoring = false
    private var mapping = false
    private var centers = HashMap<Int, Int>()
    private var lastAbs = HashMap<Int, IntArray>()   // code -> [raw, min, max]
    private var lastKeySeq = 0
    private var learning = false
    private var learnKeySeq = 0
    private var learnBase = HashMap<Int, Int>()

    // ---------------- Shizuku ----------------

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            svc = IRemapService.Stub.asInterface(b)
            say("Shizuku connected")
            refreshDevices()
        }
        override fun onServiceDisconnected(n: ComponentName) { svc = null; monitoring = false; mapping = false }
    }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) connect() else say("Shizuku permission denied")
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { connect() }

    private fun connect() {
        if (!Shizuku.pingBinder()) { say("Shizuku isn't running — start it first"); return }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(100); return }
        val args = Shizuku.UserServiceArgs(ComponentName(packageName, RemapService::class.java.name))
            .processNameSuffix("remap").daemon(false).version(1)
        Shizuku.bindUserService(args, conn)
    }

    // ---------------- UI ----------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun say(s: String) = runOnUiThread { status.text = s }
    private fun btn(label: String, f: () -> Unit) = Button(this).apply { text = label; setOnClickListener { f() } }
    private fun head(s: String) = TextView(this).apply {
        text = s; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(22), 0, dp(6))
    }
    private fun note(s: String) = TextView(this).apply { text = s; textSize = 13f; alpha = 0.7f }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("droidmap", Context.MODE_PRIVATE)
        prefs.getString("cals", null)?.let { cals.putAll(Codec.calsFromJson(JSONObject(it))) }
        prefs.getString("binds", null)?.let { binds.addAll(Codec.bindsFromJson(org.json.JSONArray(it))) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { fitsSystemWindows = true; addView(root) })

        status = TextView(this).apply { text = "Starting…" }
        root.addView(status)
        root.addView(btn("Connect to Shizuku") { connect() })

        root.addView(head("Device"))
        devSpinner = Spinner(this)
        root.addView(devSpinner)
        root.addView(btn("Refresh devices") { refreshDevices() })

        root.addView(head("Calibration"))
        root.addView(note("1) Nudge every stick/trigger once and let go, then tap Set center.\n" +
            "2) Tap Capture range and rotate each stick fully, press triggers/hat fully.\n" +
            "3) Tap Finish, then tune deadzone / invert per axis."))
        root.addView(btn("① Set center") { ensureMonitor(); centers = HashMap(lastAbs.mapValues { it.value[0] }); say("Center captured for ${centers.size} axes") })
        root.addView(btn("② Capture range") { ensureMonitor(); svc?.resetRange(); say("Move everything to its limits, then tap ③") })
        root.addView(btn("③ Finish calibration") { finishCalibration() })
        live = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 12f; setPadding(0, dp(8), 0, dp(8)) }
        root.addView(live)
        calBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(calBox)

        root.addView(head("Mapping"))
        targetSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Targets.all.map { it.label })
        }
        root.addView(targetSpinner)
        root.addView(btn("Learn: pick target above, then press/move on the device") { startLearn() })
        bindBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bindBox)

        root.addView(head("Run"))
        root.addView(btn("▶ Start mapping") { startMapping() })
        root.addView(btn("■ Stop") { svc?.stop(); mapping = false; monitoring = false; say("Stopped") })
        root.addView(note("Calibration changes apply the next time you start mapping."))

        buildCalRows(); buildBindRows()

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        ui.post(poll)
    }

    override fun onDestroy() {
        ui.removeCallbacks(poll)
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        super.onDestroy()
    }

    // ---------------- device + monitor ----------------

    private fun refreshDevices() {
        val s = svc ?: return
        devices = s.listDevices().lines().filter { it.contains('|') }.map { it.substringBefore('|') to it.substringAfter('|') }
        devSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            devices.map { "${it.second}  (${it.first.substringAfterLast('/')})" })
        devices.indexOfFirst { prefs.getString("device", "") == it.second }.takeIf { it >= 0 }?.let { devSpinner.setSelection(it) }
    }

    private fun devicePath(): String? = devices.getOrNull(devSpinner.selectedItemPosition)?.also {
        prefs.edit().putString("device", it.second).apply()
    }?.first

    private fun ensureMonitor() {
        val s = svc ?: return say("Not connected")
        if (monitoring && !mapping) return
        val p = devicePath() ?: return say("Pick a device")
        val r = s.start(p, "{}", false)
        monitoring = r.startsWith("ok"); mapping = false; lastAbs.clear(); lastKeySeq = 0
        if (!monitoring) say(r)
    }

    private val poll = object : Runnable {
        override fun run() {
            val s = svc
            if (s != null && (monitoring || mapping)) try { onSnapshot(JSONObject(s.snapshot())) } catch (e: Exception) { say(e.toString()) }
            ui.postDelayed(this, 120)
        }
    }

    private fun onSnapshot(o: JSONObject) {
        val abs = o.getJSONObject("abs")
        val sb = StringBuilder()
        val codes = abs.keys().asSequence().map { it.toInt() }.sorted().toList()
        lastAbs.clear()
        for (c in codes) {
            val a = abs.getJSONArray(c.toString())
            lastAbs[c] = intArrayOf(a.getInt(0), a.getInt(1), a.getInt(2))
            sb.append("axis %-3d raw %-6d [%d..%d]".format(c, a.getInt(0), a.getInt(1), a.getInt(2)))
            cals[c]?.let { sb.append("  → %+.2f".format(it.norm(a.getInt(0)))) }
            sb.append('\n')
        }
        live.text = sb.toString().trimEnd()
        lastKeySeq = o.getInt("keySeq")
        o.optString("err").takeIf { it.isNotEmpty() }?.let { say(it) }
        if (learning) checkLearn(o)
    }

    // ---------------- calibration ----------------

    private fun finishCalibration() {
        if (lastAbs.isEmpty()) return say("No axis data yet — move the sticks first")
        for ((c, a) in lastAbs) {
            val ctr = centers[c] ?: ((a[1] + a[2]) / 2)
            val old = cals[c]
            cals[c] = Cal(minOf(a[1], ctr), maxOf(a[2], ctr), ctr, old?.dead ?: 0.10f, old?.invert ?: false)
        }
        saveCals(); buildCalRows(); say("Calibrated ${lastAbs.size} axes")
    }

    private fun saveCals() = prefs.edit().putString("cals", Codec.calsToJson(cals).toString()).apply()

    private fun buildCalRows() {
        calBox.removeAllViews()
        for ((c, cal) in cals.toSortedMap()) {
            calBox.addView(TextView(this).apply {
                text = "axis $c   min ${cal.min}  center ${cal.center}  max ${cal.max}"
                setPadding(0, dp(12), 0, 0)
            })
            calBox.addView(TextView(this).apply { text = "Deadzone ${(cal.dead * 100).toInt()}%"; tag = "dz$c"; textSize = 12f })
            calBox.addView(SeekBar(this).apply {
                max = 40; progress = (cal.dead * 100).toInt()
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, p: Int, user: Boolean) {
                        cal.dead = p / 100f
                        calBox.findViewWithTag<TextView>("dz$c")?.text = "Deadzone $p%"
                        saveCals()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            })
            calBox.addView(CheckBox(this).apply {
                text = "Invert"; isChecked = cal.invert
                setOnCheckedChangeListener { _, v -> cal.invert = v; saveCals() }
            })
        }
    }

    // ---------------- mapping ----------------

    private fun startLearn() {
        ensureMonitor()
        learnKeySeq = lastKeySeq
        learnBase = HashMap(lastAbs.mapValues { it.value[0] })
        learning = true
        say("Press a button or move an axis on the device… (axes need calibration first)")
    }

    private fun checkLearn(o: JSONObject) {
        if (o.getInt("keySeq") > learnKeySeq) { addBinding(1, o.getInt("key"), 1); return }
        for ((c, a) in lastAbs) {
            val cal = cals[c] ?: continue
            val span = (cal.max - cal.min).coerceAtLeast(1)
            val d = a[0] - (learnBase[c] ?: cal.center)
            if (Math.abs(d).toFloat() / span > 0.4f) { addBinding(3, c, if (d > 0) 1 else -1); return }
        }
    }

    private fun addBinding(type: Int, code: Int, sign: Int) {
        learning = false
        val t = Targets.all[targetSpinner.selectedItemPosition]
        binds.removeAll { it.srcType == type && it.srcCode == code && it.target == t }
        binds.add(Binding(type, code, t, sign))
        saveBinds(); buildBindRows()
        say("Bound ${if (type == 1) "key $code" else "axis $code"} → ${t.label}")
    }

    private fun saveBinds() = prefs.edit().putString("binds", Codec.bindsToJson(binds).toString()).apply()

    private fun buildBindRows() {
        bindBox.removeAllViews()
        binds.toList().forEach { b ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val src = if (b.srcType == 1) "key ${b.srcCode}" else "axis ${b.srcCode} (${if (b.srcSign > 0) "+" else "−"})"
            row.addView(TextView(this).apply { text = "$src  →  ${b.target.label}" },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply { text = "✕"; setOnClickListener { binds.remove(b); saveBinds(); buildBindRows() } })
            bindBox.addView(row)
        }
    }

    private fun startMapping() {
        val s = svc ?: return say("Not connected")
        val p = devicePath() ?: return say("Pick a device")
        val r = s.start(p, Codec.config(binds, cals), true)
        mapping = r.startsWith("ok"); monitoring = false; learning = false
        say(if (mapping) "Mapping active — $r\nSwitch to your game." else r)
    }
}
