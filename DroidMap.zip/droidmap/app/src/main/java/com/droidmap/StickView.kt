package com.droidmap

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Live joystick tester: ring, crosshair, deadzone circle and a dot. */
class StickView(ctx: Context) : View(ctx) {
    var title = ""
    private var px = 0f
    private var py = 0f
    private var dz = 0f
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = 0x99888888.toInt()
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF888888.toInt(); textAlign = Paint.Align.CENTER; textSize = 36f
    }

    fun set(x: Float, y: Float, dead: Float) { px = x; py = y; dz = dead; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        val s = MeasureSpec.getSize(w)
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = width / 2f - 8f
        c.drawCircle(cx, cy, r, ring)
        c.drawLine(cx - r, cy, cx + r, cy, ring)
        c.drawLine(cx, cy - r, cx, cy + r, ring)
        if (dz > 0f) c.drawCircle(cx, cy, r * dz, ring)
        var mx = px.coerceIn(-1f, 1f)
        var my = py.coerceIn(-1f, 1f)
        val mag = Math.sqrt((mx * mx + my * my).toDouble()).toFloat()
        if (mag > 1f) { mx /= mag; my /= mag }
        fill.color = if (mx != 0f || my != 0f) 0xFF2E7D32.toInt() else 0xFF9E9E9E.toInt()
        c.drawCircle(cx + mx * r, cy + my * r, r * 0.1f, fill)
        c.drawText(title, cx, 42f, label)
    }
}
