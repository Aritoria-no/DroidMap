package com.droidmap

import android.view.KeyEvent
import android.view.MotionEvent
import org.json.JSONArray
import org.json.JSONObject

object Axes {
    val names = arrayOf("LS X", "LS Y", "RS X", "RS Y", "L2", "R2", "Hat X", "Hat Y")
    val ids = intArrayOf(
        MotionEvent.AXIS_X, MotionEvent.AXIS_Y, MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ,
        MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_RTRIGGER, MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_HAT_Y
    )
    fun isTrigger(i: Int) = i == 4 || i == 5
}

/** kind 0 = button (Android keycode in id), kind 1 = axis (index into Axes in id, dir = +1/-1) */
data class Target(val label: String, val kind: Int, val id: Int, val dir: Float)

/** srcType 1 = key/button, 3 = absolute axis. srcSign = physical direction (+1/-1) that was moved while learning. */
data class Binding(val srcType: Int, val srcCode: Int, val target: Target, val srcSign: Int = 1)

data class Cal(var min: Int, var max: Int, var center: Int, var dead: Float = 0.10f, var invert: Boolean = false)

/** Raw value -> -1..1 with per-direction span, deadzone and optional invert. */
fun Cal.norm(raw: Int): Float {
    val d = (raw - center).toFloat()
    val span = (if (d >= 0) max - center else center - min).toFloat()
    if (span <= 0f) return 0f
    var v = (d / span).coerceIn(-1f, 1f)
    val a = Math.abs(v)
    if (a < dead) return 0f
    v = Math.signum(v) * (a - dead) / (1f - dead)
    return if (invert) -v else v
}

object Targets {
    private val buttons = listOf(
        "A" to KeyEvent.KEYCODE_BUTTON_A, "B" to KeyEvent.KEYCODE_BUTTON_B,
        "X" to KeyEvent.KEYCODE_BUTTON_X, "Y" to KeyEvent.KEYCODE_BUTTON_Y,
        "L1" to KeyEvent.KEYCODE_BUTTON_L1, "R1" to KeyEvent.KEYCODE_BUTTON_R1,
        "L2 (button)" to KeyEvent.KEYCODE_BUTTON_L2, "R2 (button)" to KeyEvent.KEYCODE_BUTTON_R2,
        "Select" to KeyEvent.KEYCODE_BUTTON_SELECT, "Start" to KeyEvent.KEYCODE_BUTTON_START,
        "Mode" to KeyEvent.KEYCODE_BUTTON_MODE,
        "L3 (stick click)" to KeyEvent.KEYCODE_BUTTON_THUMBL, "R3 (stick click)" to KeyEvent.KEYCODE_BUTTON_THUMBR,
        "D-pad up" to KeyEvent.KEYCODE_DPAD_UP, "D-pad down" to KeyEvent.KEYCODE_DPAD_DOWN,
        "D-pad left" to KeyEvent.KEYCODE_DPAD_LEFT, "D-pad right" to KeyEvent.KEYCODE_DPAD_RIGHT
    )
    val all: List<Target> = buttons.map { Target(it.first, 0, it.second, 1f) } + listOf(
        Target("Left stick ←", 1, 0, -1f), Target("Left stick →", 1, 0, 1f),
        Target("Left stick ↑", 1, 1, -1f), Target("Left stick ↓", 1, 1, 1f),
        Target("Right stick ←", 1, 2, -1f), Target("Right stick →", 1, 2, 1f),
        Target("Right stick ↑", 1, 3, -1f), Target("Right stick ↓", 1, 3, 1f),
        Target("L2 trigger", 1, 4, 1f), Target("R2 trigger", 1, 5, 1f),
        Target("Hat ←", 1, 6, -1f), Target("Hat →", 1, 6, 1f),
        Target("Hat ↑", 1, 7, -1f), Target("Hat ↓", 1, 7, 1f)
    )
    fun find(kind: Int, id: Int, dir: Float) = all.firstOrNull { it.kind == kind && it.id == id && it.dir == dir }
}

object Codec {
    fun bindsToJson(b: List<Binding>) = JSONArray().also { arr ->
        b.forEach {
            arr.put(JSONArray().put(it.srcType).put(it.srcCode).put(it.target.kind)
                .put(it.target.id).put(it.target.dir.toDouble()).put(it.srcSign))
        }
    }

    fun bindsFromJson(a: JSONArray): List<Binding> = (0 until a.length()).mapNotNull { i ->
        val x = a.getJSONArray(i)
        Targets.find(x.getInt(2), x.getInt(3), x.getDouble(4).toFloat())
            ?.let { Binding(x.getInt(0), x.getInt(1), it, x.optInt(5, 1)) }
    }

    fun calsToJson(c: Map<Int, Cal>) = JSONObject().also { o ->
        c.forEach { (k, v) ->
            o.put(k.toString(), JSONArray().put(v.min).put(v.max).put(v.center)
                .put(v.dead.toDouble()).put(if (v.invert) 1 else 0))
        }
    }

    fun calsFromJson(o: JSONObject): MutableMap<Int, Cal> {
        val m = HashMap<Int, Cal>()
        o.keys().forEach { k ->
            val a = o.getJSONArray(k)
            m[k.toInt()] = Cal(a.getInt(0), a.getInt(1), a.getInt(2), a.getDouble(3).toFloat(), a.getInt(4) == 1)
        }
        return m
    }

    fun config(b: List<Binding>, c: Map<Int, Cal>): String =
        JSONObject().put("b", bindsToJson(b)).put("c", calsToJson(c)).toString()
}

/** Human-readable names for raw Linux input codes. */
object Names {
    private val keys = HashMap<Int, String>().apply {
        "1234567890".forEachIndexed { i, ch -> put(2 + i, ch.toString()) }
        "qwertyuiop".forEachIndexed { i, ch -> put(16 + i, ch.uppercase()) }
        "asdfghjkl".forEachIndexed { i, ch -> put(30 + i, ch.uppercase()) }
        "zxcvbnm".forEachIndexed { i, ch -> put(44 + i, ch.uppercase()) }
        for (i in 0..9) put(59 + i, "F${i + 1}")
        put(87, "F11"); put(88, "F12")
        put(1, "Esc"); put(12, "-"); put(13, "="); put(14, "Backspace"); put(15, "Tab")
        put(26, "["); put(27, "]"); put(28, "Enter"); put(29, "Left Ctrl"); put(39, ";"); put(40, "'")
        put(41, "`"); put(42, "Left Shift"); put(43, "\\"); put(51, ","); put(52, "."); put(53, "/")
        put(54, "Right Shift"); put(56, "Left Alt"); put(57, "Space"); put(58, "Caps Lock")
        put(97, "Right Ctrl"); put(100, "Right Alt")
        put(102, "Home"); put(103, "Arrow Up"); put(104, "Page Up"); put(105, "Arrow Left")
        put(106, "Arrow Right"); put(107, "End"); put(108, "Arrow Down"); put(109, "Page Down")
        put(110, "Insert"); put(111, "Delete")
        put(304, "A (south)"); put(305, "B (east)"); put(306, "C"); put(307, "X (north)")
        put(308, "Y (west)"); put(309, "Z"); put(310, "L1"); put(311, "R1"); put(312, "L2"); put(313, "R2")
        put(314, "Select"); put(315, "Start"); put(316, "Mode"); put(317, "L3 (left stick click)")
        put(318, "R3 (right stick click)")
        put(544, "D-pad up"); put(545, "D-pad down"); put(546, "D-pad left"); put(547, "D-pad right")
    }
    private val abs = mapOf(
        0 to "X", 1 to "Y", 2 to "Z", 3 to "RX", 4 to "RY", 5 to "RZ", 6 to "Throttle", 7 to "Rudder",
        9 to "Gas", 10 to "Brake", 16 to "Hat X", 17 to "Hat Y"
    )

    fun key(code: Int) = keys[code] ?: "Key $code"
    fun abs(code: Int) = "Axis $code" + (abs[code]?.let { " ($it)" } ?: "")
}
