package com.droidmap

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileDescriptor
import java.io.FileInputStream
import java.lang.reflect.Method
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.system.exitProcess

/**
 * Runs inside Shizuku's shell-uid process (bound as a Shizuku "user service").
 * Reads raw evdev events from /dev/input/eventN, applies mapping + calibration,
 * and injects gamepad-sourced KeyEvents / MotionEvents through IInputManager.
 */
class RemapService : IRemapService.Stub() {

    init {
        SvcDiag.w("service constructed pid=${android.os.Process.myPid()} uid=${android.os.Process.myUid()}")
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            SvcDiag.w("CRASH: " + android.util.Log.getStackTraceString(e))
            prev?.uncaughtException(t, e)
        }
    }

    private class Cfg(val binds: List<Binding>, val cals: Map<Int, Cal>) {
        val pressed = BooleanArray(binds.size)
    }

    private val lock = Any()
    @Volatile private var cfg = Cfg(emptyList(), emptyMap())
    @Volatile private var injecting = false
    @Volatile private var grabbed = false
    @Volatile private var grabNote = ""
    private var devPath = ""
    @Volatile private var stream: FileInputStream? = null
    private var downTime = 0L

    private val absLast = HashMap<Int, Int>()
    private val absMin = HashMap<Int, Int>()
    private val absMax = HashMap<Int, Int>()
    private val absFirst = HashMap<Int, Int>()
    private var keySeq = 0
    private var lastKey = -1
    private var err = ""

    private val btnCount = HashMap<Int, Int>()
    private val contrib = Array(Axes.ids.size) { HashMap<Int, Float>() }
    private var axisDirty = false

    private var im: Any? = null
    private var injectM: Method? = null

    private fun parse(json: String): Cfg {
        val o = JSONObject(json)
        return Cfg(
            o.optJSONArray("b")?.let { Codec.bindsFromJson(it) } ?: emptyList(),
            o.optJSONObject("c")?.let { Codec.calsFromJson(it) } ?: emptyMap()
        )
    }

    private fun setErr(s: String) = synchronized(lock) { err = s }

    // ---------------- AIDL ----------------

    override fun detect(ms: Int): String {
        val files = File("/dev/input").listFiles { f -> f.name.startsWith("event") }
            ?.sortedBy { it.name.removePrefix("event").toIntOrNull() ?: 0 }
            ?: return "!can't list /dev/input\n"
        val counts = LinkedHashMap<String, IntArray>() // path -> [pad button presses, other key presses, axis moves]
        val opened = ArrayList<FileInputStream>()
        var failed = 0
        for (f in files) {
            val s = try { FileInputStream(f) } catch (_: Throwable) { failed++; continue }
            opened.add(s)
            val c = IntArray(3)
            counts[f.path] = c
            Thread {
                val buf = ByteArray(24)
                val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
                try {
                    while (true) {
                        var n = 0
                        while (n < 24) { val r = s.read(buf, n, 24 - n); if (r < 0) return@Thread; n += r }
                        val type = bb.getShort(16).toInt() and 0xFFFF
                        val code = bb.getShort(18).toInt() and 0xFFFF
                        val value = bb.getInt(20)
                        if (type == 1 && value == 1) {
                            if ((code in 0x100..0x13f) || (code in 0x220..0x2e7)) c[0]++
                            else if (code !in 0x140..0x14f) c[1]++
                        } else if (type == 3 && code <= 0x11) c[2]++
                    }
                } catch (_: Throwable) {}
            }.also { it.isDaemon = true; it.start() }
        }
        try { Thread.sleep(ms.toLong()) } catch (_: InterruptedException) {}
        for (s in opened) try { s.close() } catch (_: Throwable) {}
        val sb = StringBuilder()
        for ((p, c) in counts) if (c[0] > 0 || c[1] > 0 || c[2] > 0) sb.append(p).append('|').append(c[0]).append('|').append(c[1]).append('|').append(c[2]).append('\n')
        if (failed > 0) sb.append("!couldn't open $failed device(s)\n")
        return sb.toString()
    }

    override fun destroy() { SvcDiag.w("destroy() called"); stop(); exitProcess(0) }

    override fun listDevices(): String {
        val out = StringBuilder()
        try {
            for (blk in File("/proc/bus/input/devices").readText().split("\n\n")) {
                val name = Regex("Name=\"(.*)\"").find(blk)?.groupValues?.get(1) ?: continue
                val h = Regex("Handlers=(.*)").find(blk)?.groupValues?.get(1) ?: ""
                val ev = Regex("event\\d+").find(h)?.value ?: continue
                val kind = if (Regex("\\bjs\\d+").containsMatchIn(h)) "pad" else if (h.contains("kbd")) "kbd" else "other"
                out.append("/dev/input/$ev|$name|$kind\n")
            }
        } catch (e: Throwable) {
            out.append("!/proc/bus/input/devices failed: $e\n")
        }
        if (!out.contains('|')) {
            try {
                File("/dev/input").listFiles { f -> f.name.startsWith("event") }?.sortedBy { it.name }?.forEach { f ->
                    val name = try { File("/sys/class/input/${f.name}/device/name").readText().trim() } catch (_: Throwable) { "Input device" }
                    out.append("${f.path}|$name|other\n")
                }
                out.append("!used /dev/input fallback\n")
            } catch (e: Throwable) {
                out.append("!/dev/input failed: $e\n")
            }
        }
        return out.toString()
    }

    override fun start(devicePath: String, configJson: String, inject: Boolean): String {
        return try {
            stopReader()
            cfg = parse(configJson)
            btnCount.clear(); contrib.forEach { it.clear() }
            synchronized(lock) { absLast.clear(); absMin.clear(); absMax.clear(); absFirst.clear(); err = "" }
            devPath = devicePath
            grabNote = ""
            downTime = SystemClock.uptimeMillis()
            var injectError = ""
            injecting = false
            if (inject) {
                try { ensureInjector(); injecting = true } catch (e: Throwable) { injectError = e.toString() }
            }
            openReader(injecting)
            when {
                injectError.isNotEmpty() -> "error: can't inject ($injectError). Calibration and the tester still work."
                injecting && grabbed -> "ok — mapping on, exclusive"
                injecting -> "ok — mapping on, shared (the raw device may also reach the game). Grab failed: $grabNote"
                else -> "ok — mapping off"
            }
        } catch (e: Throwable) {
            "error: $e"
        }
    }

    override fun setConfig(configJson: String) {
        try {
            if (injecting) try { releaseAll() } catch (_: Throwable) {}
            cfg = parse(configJson)
        } catch (e: Throwable) { setErr("config: $e") }
    }

    override fun setInject(inject: Boolean) {
        try {
            if (inject == injecting) return
            if (inject) {
                ensureInjector()
                injecting = true
                if (!grabbed && devPath.isNotEmpty()) openReader(true)
            } else {
                try { releaseAll() } catch (_: Throwable) {}
                injecting = false
                if (grabbed && devPath.isNotEmpty()) openReader(false)
            }
        } catch (e: Throwable) { setErr("inject: $e") }
    }

    override fun stop() {
        stopReader()
        if (injecting) try { releaseAll() } catch (_: Throwable) {}
        injecting = false
    }

    override fun snapshot(): String = synchronized(lock) {
        val abs = JSONObject()
        for ((c, v) in absLast) {
            abs.put(c.toString(), JSONArray().put(v).put(absMin[c]!!).put(absMax[c]!!).put(absFirst[c]!!))
        }
        JSONObject().put("keySeq", keySeq).put("key", lastKey).put("err", err)
            .put("inject", injecting).put("grabbed", grabbed).put("abs", abs).toString()
    }

    override fun resetRange() = synchronized(lock) {
        for ((c, v) in absLast) { absMin[c] = v; absMax[c] = v; absFirst[c] = v }
    }

    // ---------------- reader ----------------

    private fun stopReader() {
        val f = stream
        stream = null
        grabbed = false
        try { f?.close() } catch (_: Throwable) {}
    }

    private fun openReader(grab: Boolean) {
        try { stream?.close() } catch (_: Throwable) {}
        val f = FileInputStream(devPath)
        stream = f
        grabbed = grab && tryGrab(f)
        Thread { loop(f) }.also { it.isDaemon = true; it.start() }
    }

    private fun loop(f: FileInputStream) {
        val buf = ByteArray(24) // struct input_event (64-bit): 16B timeval, u16 type, u16 code, s32 value
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        try {
            while (stream === f) {
                var n = 0
                while (n < 24) { val r = f.read(buf, n, 24 - n); if (r < 0) return; n += r }
                val type = bb.getShort(16).toInt() and 0xFFFF
                val code = bb.getShort(18).toInt() and 0xFFFF
                val value = bb.getInt(20)
                onEvent(type, code, value)
            }
        } catch (e: Throwable) {
            if (stream === f) setErr("reader: $e")
        }
    }

    private fun onEvent(type: Int, code: Int, value: Int) {
        when (type) {
            1 -> if (value != 2) {
                if (value == 1) synchronized(lock) { lastKey = code; keySeq++ }
                if (injecting) guarded { apply(type, code, value) }
            }
            3 -> {
                synchronized(lock) {
                    absLast[code] = value
                    absMin[code] = minOf(absMin[code] ?: value, value)
                    absMax[code] = maxOf(absMax[code] ?: value, value)
                    if (!absFirst.containsKey(code)) absFirst[code] = value
                }
                if (injecting) guarded { apply(type, code, value) }
            }
            0 -> if (code == 0 && axisDirty && injecting) { guarded { sendAxes() }; axisDirty = false }
        }
    }

    private inline fun guarded(block: () -> Unit) {
        try { block() } catch (e: Throwable) { setErr("inject: $e") }
    }

    // ---------------- mapping ----------------

    private fun apply(type: Int, code: Int, value: Int) {
        val c = cfg
        for (i in c.binds.indices) {
            val b = c.binds[i]
            if (b.srcType != type || b.srcCode != code) continue
            val t = b.target
            if (type == 1) {
                val down = value == 1
                if (t.kind == 0) setButton(c, i, t.id, down)
                else { contrib[t.id][i] = if (down) t.dir else 0f; axisDirty = true }
            } else {
                val v = (c.cals[code] ?: Cal(0, 255, 128)).norm(value) * b.srcSign * t.dir
                if (t.kind == 0) setButton(c, i, t.id, v > 0.5f)
                else { contrib[t.id][i] = v; axisDirty = true }
            }
        }
    }

    private fun setButton(c: Cfg, i: Int, key: Int, down: Boolean) {
        if (c.pressed[i] == down) return
        c.pressed[i] = down
        val n = ((btnCount[key] ?: 0) + if (down) 1 else -1).coerceAtLeast(0)
        btnCount[key] = n
        if (down && n == 1) sendKey(key, KeyEvent.ACTION_DOWN)
        if (!down && n == 0) sendKey(key, KeyEvent.ACTION_UP)
    }

    private fun releaseAll() {
        for ((k, n) in btnCount) if (n > 0) sendKey(k, KeyEvent.ACTION_UP)
        btnCount.clear(); contrib.forEach { it.clear() }
        sendAxes()
    }

    // ---------------- injection ----------------

    private fun ensureInjector() {
        if (im != null && injectM != null) return
        val binder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, "input") as IBinder
        val obj = Class.forName("android.hardware.input.IInputManager\$Stub")
            .getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
        injectM = obj.javaClass.methods.filter { it.name == "injectInputEvent" }.minByOrNull { it.parameterTypes.size }
            ?: throw NoSuchMethodException("injectInputEvent not found")
        im = obj
    }

    private fun inject(e: InputEvent) {
        val m = injectM!!
        if (m.parameterTypes.size == 2) m.invoke(im, e, 0) else m.invoke(im, e, 0, -1) // 0 = async, -1 = any uid
    }

    private fun sendKey(code: Int, action: Int) {
        val now = SystemClock.uptimeMillis()
        inject(KeyEvent(now, now, action, code, 0, 0, -1, 0, 0, InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_KEYBOARD))
    }

    private fun sendAxes() {
        val props = MotionEvent.PointerProperties().apply { id = 0; toolType = MotionEvent.TOOL_TYPE_UNKNOWN }
        val coords = MotionEvent.PointerCoords().apply {
            clear()
            for (a in Axes.ids.indices) {
                val s = contrib[a].values.sum()
                setAxisValue(Axes.ids[a], if (Axes.isTrigger(a)) s.coerceIn(0f, 1f) else s.coerceIn(-1f, 1f))
            }
        }
        val ev = MotionEvent.obtain(
            downTime, SystemClock.uptimeMillis(), MotionEvent.ACTION_MOVE, 1,
            arrayOf(props), arrayOf(coords), 0, 0, 1f, 1f, -1, 0, InputDevice.SOURCE_JOYSTICK, 0
        )
        try { inject(ev) } finally { ev.recycle() }
    }

    /** Best effort EVIOCGRAB so the raw device stops reaching other apps (closing the fd releases it). */
    private fun tryGrab(f: FileInputStream): Boolean {
        val cmd = 0x40044590 // EVIOCGRAB; the kernel treats any non-null argument as "grab"
        val notes = StringBuilder()
        try { // older Android: ioctlInt(fd, cmd, Int32Ref)
            val ref = Class.forName("android.system.Int32Ref").getConstructor(Int::class.javaPrimitiveType).newInstance(1)
            Class.forName("android.system.Os")
                .getMethod("ioctlInt", FileDescriptor::class.java, Int::class.javaPrimitiveType, ref.javaClass)
                .invoke(null, f.fd, cmd, ref)
            return true
        } catch (e: Throwable) { notes.append("3-arg: ").append((e.cause ?: e).toString()).append("; ") }
        try { // newer Android: ioctlInt(fd, cmd)
            Class.forName("android.system.Os")
                .getMethod("ioctlInt", FileDescriptor::class.java, Int::class.javaPrimitiveType)
                .invoke(null, f.fd, cmd)
            return true
        } catch (e: Throwable) { notes.append("2-arg: ").append((e.cause ?: e).toString()) }
        grabNote = notes.toString()
        SvcDiag.w("grab failed: $grabNote")
        return false
    }
}

/** Startup diagnostics written from the Shizuku (shell) process so the app can read them if binding fails. */
internal object SvcDiag {
    private const val APP_FILE = "/sdcard/Android/data/com.droidmap/files/service.log"
    private const val TMP_FILE = "/data/local/tmp/droidmap-service.log"
    fun w(s: String) {
        val line = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date()) + " " + s + "\n"
        for (p in arrayOf(APP_FILE, TMP_FILE)) {
            try { java.io.FileOutputStream(p, true).use { it.write(line.toByteArray()) } } catch (_: Throwable) {}
        }
    }
}
