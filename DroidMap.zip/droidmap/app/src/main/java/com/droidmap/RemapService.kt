package com.droidmap

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileDescriptor
import java.io.FileInputStream
import java.lang.reflect.Method
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.system.exitProcess

/**
 * Runs inside Shizuku's shell-uid process (bound as a Shizuku "user service").
 * Reads raw evdev events from /dev/input/eventN, applies the mapping + calibration,
 * and injects gamepad-sourced KeyEvents / MotionEvents through IInputManager.
 */
class RemapService : IRemapService.Stub() {

    private val lock = Any()
    @Volatile private var running = false
    private var injecting = false
    private var stream: FileInputStream? = null
    private var thread: Thread? = null

    // monitor state
    private val absLast = HashMap<Int, Int>()
    private val absMin = HashMap<Int, Int>()
    private val absMax = HashMap<Int, Int>()
    private var keySeq = 0
    private var lastKey = -1
    @Volatile private var err = ""

    // mapping state
    private var binds: List<Binding> = emptyList()
    private var cals: Map<Int, Cal> = emptyMap()
    private var pressed = BooleanArray(0)
    private val btnCount = HashMap<Int, Int>()
    private val contrib = Array(Axes.ids.size) { HashMap<Int, Float>() }
    private var axisDirty = false
    private var downTime = 0L

    // injector (reflection on hidden IInputManager)
    private var im: Any? = null
    private var injectM: Method? = null

    override fun destroy() { stop(); exitProcess(0) }

    override fun listDevices(): String {
        val out = StringBuilder()
        var name = ""
        File("/proc/bus/input/devices").readText().lines().forEach { l ->
            if (l.startsWith("N: Name=")) name = l.substringAfter("Name=").trim('"')
            else if (l.startsWith("H: Handlers=")) {
                Regex("event\\d+").find(l)?.let { out.append("/dev/input/${it.value}|$name\n") }
            }
        }
        return out.toString()
    }

    override fun start(devicePath: String, configJson: String, inject: Boolean): String {
        stop()
        return try {
            val cfg = JSONObject(configJson)
            binds = cfg.optJSONArray("b")?.let { Codec.bindsFromJson(it) } ?: emptyList()
            cals = cfg.optJSONObject("c")?.let { Codec.calsFromJson(it) } ?: emptyMap()
            pressed = BooleanArray(binds.size)
            btnCount.clear(); contrib.forEach { it.clear() }
            synchronized(lock) { absLast.clear(); absMin.clear(); absMax.clear(); err = "" }
            if (inject) setupInjector()
            val f = FileInputStream(devicePath)
            stream = f
            val grabbed = inject && tryGrab(f)
            injecting = inject
            downTime = SystemClock.uptimeMillis()
            running = true
            thread = Thread { loop(f) }.also { it.isDaemon = true; it.start() }
            "ok" + if (grabbed) " (exclusive)" else if (inject) " (shared: device also reaches the game)" else ""
        } catch (e: Throwable) {
            "error: $e"
        }
    }

    override fun stop() {
        running = false
        try { stream?.close() } catch (_: Throwable) {}
        stream = null
        if (injecting) try { releaseAll() } catch (_: Throwable) {}
        injecting = false
    }

    override fun snapshot(): String = synchronized(lock) {
        val abs = JSONObject()
        for ((c, v) in absLast) abs.put(c.toString(), JSONArray().put(v).put(absMin[c]!!).put(absMax[c]!!))
        JSONObject().put("keySeq", keySeq).put("key", lastKey).put("err", err).put("abs", abs).toString()
    }

    override fun resetRange() = synchronized(lock) {
        for ((c, v) in absLast) { absMin[c] = v; absMax[c] = v }
    }

    // ---------------- reader ----------------

    private fun loop(f: FileInputStream) {
        val buf = ByteArray(24) // struct input_event on 64-bit: 16B timeval, u16 type, u16 code, s32 value
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        try {
            while (running) {
                var n = 0
                while (n < 24) { val r = f.read(buf, n, 24 - n); if (r < 0) return; n += r }
                val type = bb.getShort(16).toInt() and 0xFFFF
                val code = bb.getShort(18).toInt() and 0xFFFF
                val value = bb.getInt(20)
                onEvent(type, code, value)
            }
        } catch (e: Throwable) {
            if (running) synchronized(lock) { err = e.toString() }
        }
    }

    private fun onEvent(type: Int, code: Int, value: Int) {
        when (type) {
            1 -> if (value != 2) {
                if (value == 1) synchronized(lock) { lastKey = code; keySeq++ }
                if (injecting) guarded { apply(1, code, value) }
            }
            3 -> {
                synchronized(lock) {
                    absLast[code] = value
                    absMin[code] = minOf(absMin[code] ?: value, value)
                    absMax[code] = maxOf(absMax[code] ?: value, value)
                }
                if (injecting) guarded { apply(3, code, value) }
            }
            0 -> if (code == 0 && axisDirty && injecting) { guarded { sendAxes() }; axisDirty = false }
        }
    }

    private inline fun guarded(block: () -> Unit) {
        try { block() } catch (e: Throwable) { synchronized(lock) { err = "inject: $e" } }
    }

    // ---------------- mapping ----------------

    private fun apply(type: Int, code: Int, value: Int) {
        for (i in binds.indices) {
            val b = binds[i]
            if (b.srcType != type || b.srcCode != code) continue
            val t = b.target
            if (type == 1) {
                val down = value == 1
                if (t.kind == 0) setButton(i, t.id, down)
                else { contrib[t.id][i] = if (down) t.dir else 0f; axisDirty = true }
            } else {
                val v = (cals[code] ?: Cal(0, 255, 128)).norm(value) * b.srcSign * t.dir
                if (t.kind == 0) setButton(i, t.id, v > 0.5f)
                else { contrib[t.id][i] = v; axisDirty = true }
            }
        }
    }

    private fun setButton(i: Int, key: Int, down: Boolean) {
        if (pressed[i] == down) return
        pressed[i] = down
        val n = ((btnCount[key] ?: 0) + if (down) 1 else -1).coerceAtLeast(0)
        btnCount[key] = n
        if (down && n == 1) sendKey(key, KeyEvent.ACTION_DOWN)
        if (!down && n == 0) sendKey(key, KeyEvent.ACTION_UP)
    }

    private fun releaseAll() {
        for ((k, n) in btnCount) if (n > 0) sendKey(k, KeyEvent.ACTION_UP)
        btnCount.clear(); contrib.forEach { it.clear() }
        sendAxes()
    }

    // ---------------- injection ----------------

    private fun setupInjector() {
        val binder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, "input") as IBinder
        val obj = Class.forName("android.hardware.input.IInputManager\$Stub")
            .getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
        im = obj
        injectM = obj.javaClass.methods.filter { it.name == "injectInputEvent" }.minByOrNull { it.parameterTypes.size }
            ?: throw NoSuchMethodException("injectInputEvent not found")
    }

    private fun inject(e: InputEvent) {
        val m = injectM!!
        if (m.parameterTypes.size == 2) m.invoke(im, e, 0) else m.invoke(im, e, 0, -1) // 0 = async, -1 = any target uid
    }

    private fun sendKey(code: Int, action: Int) {
        val now = SystemClock.uptimeMillis()
        inject(KeyEvent(now, now, action, code, 0, 0, -1, 0, 0, InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_KEYBOARD))
    }

    private fun sendAxes() {
        val props = MotionEvent.PointerProperties().apply { id = 0; toolType = MotionEvent.TOOL_TYPE_UNKNOWN }
        val coords = MotionEvent.PointerCoords().apply {
            clear()
            for (a in Axes.ids.indices) {
                val s = contrib[a].values.sum()
                setAxisValue(Axes.ids[a], if (Axes.isTrigger(a)) s.coerceIn(0f, 1f) else s.coerceIn(-1f, 1f))
            }
        }
        val ev = MotionEvent.obtain(
            downTime, SystemClock.uptimeMillis(), MotionEvent.ACTION_MOVE, 1,
            arrayOf(props), arrayOf(coords), 0, 0, 1f, 1f, -1, 0, InputDevice.SOURCE_JOYSTICK, 0
        )
        try { inject(ev) } finally { ev.recycle() }
    }

    /** Best effort EVIOCGRAB so the raw device stops reaching the game too. */
    private fun tryGrab(f: FileInputStream): Boolean = try {
        val ref = Class.forName("android.system.Int32Ref").getConstructor(Int::class.javaPrimitiveType).newInstance(1)
        Class.forName("android.system.Os")
            .getMethod("ioctlInt", FileDescriptor::class.java, Int::class.javaPrimitiveType, ref.javaClass)
            .invoke(null, f.fd, 0x40044590, ref)
        true
    } catch (_: Throwable) { false }
}
